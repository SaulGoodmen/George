<?php

// print <<<EOT
// <script type="text/javascript">			
	
// var parameterName = "parameterName",				// 统一参数名前缀
// 	unifiedIdName = "htmlCode",						// 统一参数值前缀
// 	name,											// 参数名
// 	values,											// 参数值
// 	tmpArr,											// 第三变量数组
// 	QueryString,									// 问号之后的URL字符串
// 	whyIndex,										// 问号的下标索引
// 	URL = document.location.toString(),			// URL地址
// 	text = "";
	
// if(URL.lastIndexOf("?") != -1){ 

// 	QueryString = URL.substring(URL.lastIndexOf("?")+1, URL.length); 		// 判断URL是否带参数传递
// 	tmpArr = QueryString.split("&");				// 分离参数地址中and符号的每一个参数块

// 	for (var i=0; i < tmpArr.length; i++) {
	
// 		whyIndex = tmpArr[i].indexOf("=");
// 		if(whyIndex > 0){
		
// 			name = tmpArr[i].substring(0, whyIndex) ;			// 获取参数名	
// 			values = tmpArr[i].substring(whyIndex + 1) ;		// 获取参数值
// 			if(document.getElementById(parameterName + (i + 1) + "") != null){			// 判断是否找到控件
// 				document.getElementById(parameterName + (i + 1) + "").value = name ;	// 给指定id赋参数名
// 			}
// 			if(document.getElementById(unifiedIdName + (i + 1) + "") != null){			// 判断是否找到控件
// 				document.getElementById(unifiedIdName + (i + 1) + "").value = values ;	// 给指定id赋参数值
// 			}
// 		}
// 	}
// } else {
// 	QueryString = "";
// }
// console.log(values);
//  function to(){
// 	console.log("test.html?="+values)
// 	if(values){
// 		window.location.href='test.html?Uname='+values;
// 	}else{
// 	 	window.location.href='test.html?Uname='+values;
// 	}

// }
// values = "1234";

// saveGame(values);
// function saveGame(str){
// 	url = window.location.href;
// 	window.location.href= url+'?str=' + str;
// }
// </script>
// EOT;
$name = $_GET["Uname"];
$dbhost = "localhost";
$charset = 'utf8';
$dbname = "george";	//数据库名称
$dbuser = "admin";		//数据库用户名
$dbpass = "88888888";	//数据库密码
$tbname = 'info'; 	//表格名 
$value = "123455";
try
{
	$conn =  new PDO("mysql:host=$dbhost;dbname=$dbname;charset=$charset", $dbuser, $dbpass);
	//mysql_select_db('info');
	$sql = "SELECT Uid,age,sex,Tel FROM info where Uname='$name'";
	//echo $sql;
	if (!$conn)
	{
	  die('Could not connect: ' . mysql_error());
	  echo "Qu111ery failed\n";
	}
	$query = $conn->prepare($sql);
	$query->bindParam(1,$Uid);
	$query->bindParam(2,$age);
	$query->bindParam(3,$sex);
	$query->bindParam(4,$Tel);
	if ( $query->execute() ) 
	{
		$numrows = $query->rowCount();
		for($i = 0 ;$i<$numrows;$i++){
			$rowset = $query->fetch();
		}
	}
	else
	{
		echo "Query failed\n";
	}
	$conn = null; // 关闭连接
}
catch(PDOException $e)
{
	echo $e->getMessage();
}

	print <<<EOT
			<form action="submit.php?Uname=$name" method="post" enctype="multipart/form-data" >
			Uid:<br>
			<input type="text" name="uid" value="$rowset[0]">
			<br>
			Age:<br>
			<input type="text" name="age" value="$rowset[1]">
			<br>
			Sex:<br>
			<input type="text" name="sex" value="$rowset[2]">
			<br>
			Tel:<br>
			<input type="text" name="tel" value= "$rowset[3]">
			<br>
			<br>
			<input type="submit" value="Submit">
			</form> 
EOT;
?>