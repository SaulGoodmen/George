<?php 
/**
* 登录验证
*/

$dbhost = "localhost";
$charset = 'utf8';
$dbname = "george";	//数据库名称
$dbuser = "admin";		//数据库用户名
$dbpass = "88888888";	//数据库密码
$tbname = 'info'; 	//表格名
$name=$_POST['name'];  
$password=$_POST['password'];  

try
{
	$conn = new PDO("mysql:host=$dbhost;dbname=$dbname;charset=$charset", $dbuser, $dbpass);
	$sql = "SELECT * FROM info where Uname='$name'and Upassword='$password'";

	if (!$conn)
	{
	  die('Could not connect: ' . mysql_error());
	  echo "Qu111ery failed\n";
	}
	
	if ( $query = $conn->query($sql) ) 
	{
		if($query->rowCount()<1)	//如果数据库中找不到对应数据
		{
			echo"<script type='text/javascript'>alert('账号或密码错误'); location='sign.php';</script>";  
		}
		else
		{	
			echo"<script type='text/javascript'>alert('登陆成功');
				location.replace('george.html?Uname='+$name)</script>";  
		}
	}
	else
	{
		echo "Query failed\n";
	}
	$conn = null; // 关闭连接
}
catch(PDOException $e)
{
	echo $e->getMessage();
}

?>