<?php
$name = $_GET["Uname"];
$dbhost = "localhost";
$charset = 'utf8';
$dbname = "george";	//数据库名称
$dbuser = "admin";		//数据库用户名
$dbpass = "88888888";	//数据库密码
$tbname = 'info'; 	//表格名
$uid=$_POST['uid'];
$age=$_POST['age'];  
$sex=$_POST['sex'];
$tel=$_POST['tel'];

try
{
	$conn = new PDO("mysql:host=$dbhost;dbname=$dbname;charset=$charset", $dbuser, $dbpass);
	$sql = "UPDATE info SET Uid='$uid',age='$age',sex='$sex',Tel='$tel' WHERE Uname='$name'";

	if (!$conn)
	{
	  die('Could not connect: ' . mysql_error());
	  echo "Qu111ery failed\n";
	}

	$conn->query($sql);
	$conn = null; // 关闭连接
}
catch(PDOException $e)
{
	echo $e->getMessage();
}
 echo"<script type='text/javascript'>alert('修改成功！');location.replace('george.html?Uname='+$name)</script>"; 
?>